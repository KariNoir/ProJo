package com.ProJo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProJoApplicationTests {

	@Test
	void contextLoads() {
	}

}
